package entity;

public class JenisPakaian 
{
    private int id_jenis_pakaian;
    private String nama_jenis_pakaian;
    
    public JenisPakaian()
    {
        
    }
    
    public int getId_jenis_pakaian() 
    {
        return id_jenis_pakaian;
    }

    public void setId_jenis_pakaian(int id_jenis_pakaian) 
    {
        this.id_jenis_pakaian = id_jenis_pakaian;
    }

    public String getNama_jenis_pakaian() 
    {
        return nama_jenis_pakaian;
    }

    public void setNama_jenis_pakaian(String nama_jenis_pakaian) 
    {
        this.nama_jenis_pakaian = nama_jenis_pakaian;
    } 
}
